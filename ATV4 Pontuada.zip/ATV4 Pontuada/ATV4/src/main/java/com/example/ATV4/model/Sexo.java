package com.example.ATV4.model;

public enum Sexo {
    MASCULINO,
    FEMININO
}
